import java.util.HashMap;
import java.util.Map;

/**
 * Example DataStore class that provides access to user data.
 * Pretend this class accesses a database.
 */
public class DataStore {


	//Map of names to Person instances.
	private Map<String, ProjectObject> projectMap = new HashMap<String, ProjectObject>();
	
	//this class is a singleton and should not be instantiated directly!
	private static DataStore instance = new DataStore();
	public static DataStore getInstance(){
		return instance;
	}

	//private constructor so people know to use the getInstance() function instead
	private DataStore(){
		//dummy data
		projectMap.put("Project 1", new ProjectObject("Project 1", "01-Jan-20", "123", "ACTIVE", "ABC", "11RRRR"));
		projectMap.put("Project 2", new ProjectObject("Project 2", "02-Jan-20", "123", "DRAFT", "ABC", "11RRRR"));

	}

	public ProjectObject getProject(String name) {
		return projectMap.get(name);
	}

	public void putProject(ProjectObject project) {
		projectMap.put(project.getName(), project);
		System.out.println("Project put");
		System.out.println(project.getName());
		System.out.println(project.getStatus());
		System.out.println(project.getClientID());
		System.out.println(project.getProjectReference());
		System.out.println(project.getProjectManagerID());
		System.out.println(projectMap);

	}
}
