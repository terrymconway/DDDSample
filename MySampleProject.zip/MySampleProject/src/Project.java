



public class Project {

	String draft(String name, String endDate, String clientID)
	{
		clientID c = new clientID(clientID);
		DataStore.getInstance().putProject(new ProjectObject(name, endDate, c.value, "DRAFT", "", ""));
		return name;
	}

	void start(String projectName, String projectManagerID) throws Exception
	{
		ProjectObject p = DataStore.getInstance().getProject("My Project");
		projectStatus s = new projectStatus("ACTIVE");
		p.setStatus(s.value);
		p.setProjectManagerID(projectManagerID);
		DataStore.getInstance().putProject(p);
		
		
		System.out.println("Project" + projectName + " Started for " + projectManagerID);
	}

	void addSpecialist(String projectName, String specialistID)
	{
		System.out.println("Specialist" + specialistID + " added to  Project" + projectName);
	}

	void removeSpecialist(String projectName, String specialistID)
	{
		System.out.println("Specialist" + specialistID + " removed from Project" + projectName);

	}

	void approveSpecialist(String projectName, String specialistID)
	{
		System.out.println("Specialist" + specialistID + " approved for Project" + projectName);
	}
	
	class clientID
	{
		String value; 
		
		clientID(String value)
		{
			this.value = value;
		}
	}

	class projectStatus
	{
		String value; 
		projectStatus(String value) throws Exception
		{
			if (value != "ACTIVE"  && value != "DRAFT")
			{
				throw new Exception("Bad Status!!");			}
			else
			{
				this.value = value;
			}
			}
	}
	
	
}
