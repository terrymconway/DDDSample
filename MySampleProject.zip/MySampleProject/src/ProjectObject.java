	public class ProjectObject {
		private String name;


		private String endDate;
		private String clientID;
		private String status;
		private String projectManagerID;
		private String projectReference;

		public String getName() {
			return name;
		}

		public void setName(String name) {
			this.name = name;
		}

		public String getClientID() {
			return clientID;
		}

		public void setClientID(String clientID) {
			this.clientID = clientID;
		}

		public String getStatus() {
			return status;
		}

		public void setStatus(String status) {
			this.status = status;
		}

		public String getProjectManagerID() {
			return projectManagerID;
		}

		public void setProjectManagerID(String projectManagerID) {
			this.projectManagerID = projectManagerID;
		}

		public String getProjectReference() {
			return projectReference;
		}

		public void setProjectReference(String projectReference) {
			this.projectReference = projectReference;
		}

		public void setEndDate(String endDate) {
			this.endDate = endDate;
		}
		
		
		
		public ProjectObject(String name, String endDate, String clientID, String status, String projectManagerID, String projectReference) {
			this.name = name;
			this.endDate = endDate;
			this.clientID = clientID;
			this.status = status;
			this.projectManagerID = projectManagerID;
			this.projectReference = projectReference;
						
		}



	}