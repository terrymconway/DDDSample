
public class Main {

	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		String sReference = "";
			
		Project p = new Project();
		sReference = p.draft("My Project", "My Date", "My ClientID");
		System.out.println(sReference);
		p.start(sReference, "ABC");
		

		
		
	}

}
